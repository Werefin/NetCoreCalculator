﻿using Microsoft.AspNetCore.Mvc;
using NetCoreCalculator.Utility;
using NetCoreCalculator.Models;

namespace NetCoreCalculator.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult About()
        {
            return View();
        }

        [HttpGet]
        public IActionResult CompoundInterest()
        {
            return View();
        }

        [HttpGet]
        public IActionResult NetworkTroughput()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Operation model)
        {
            if (model.OperationType == OperationType.Addition)
            {
                model.Result = model.NumberA + model.NumberB;
            }
            else if (model.OperationType == OperationType.Subtraction)
            {
                model.Result = model.NumberA - model.NumberB;
            }
            else if (model.OperationType == OperationType.Multiplication)
            {
                model.Result = model.NumberA * model.NumberB;
            }
            else if (model.OperationType == OperationType.Division)
            {
                model.Result = model.NumberA / model.NumberB;
            }
            return View(model);
        }

        [HttpPost]
        public IActionResult CompoundInterest(CompoundInterestModel model)
        {
            model.Result = Calculation.CalculateCompoundInterest(model);
            return View(model);
        }

        [HttpPost]
        public IActionResult NetworkTroughput(NetworkTroughputModel model)
        {
            model.Result = Calculation.CalculateNetworkTroughput(model);
            return View(model);
        }
    }
}