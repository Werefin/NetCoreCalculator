﻿using System.ComponentModel.DataAnnotations;

namespace NetCoreCalculator.Models
{
    public class CompoundInterestModel
    {
        [Display(Name = "Result - A")]
        public double Result { get; set; }

        [Display(Name = "Initial Investment - II [$]")]
        [Range(0.1, double.MaxValue, ErrorMessage = "Initial Investment should be valid!")]
        public double Investment { get; set; }

        [Display(Name = "Interest Rate - IR [%]")]
        [Range(1, 100, ErrorMessage = "Interest Rate should be valid!")]
        public double InterestRate { get; set; }

        [Display(Name = "Period of Time - PoT [Year]")]
        [Range(0.5, int.MaxValue, ErrorMessage = "Period of Time should be valid!")]
        public int TimePeriod { get; set; }
    }
}