﻿using System.ComponentModel.DataAnnotations;

namespace NetCoreCalculator.Models
{
    public class NetworkTroughputModel
    {
        [Display(Name = "Result - THR [Mb/s]")]
        public double Result { get; set; }

        [Display(Name = "Protocol Efficiency - PE")]
        [Range(0.1, 1, ErrorMessage = "It's necessary to insert a valid PE (0,1]!")]
        public double ProtocolEfficiency { get; set; }

        [Display(Name = "Transmission Capacity - TC [Mb/s]")]
        [Range(0.1, double.MaxValue, ErrorMessage = "It's necessary to insert a valid TC!")]
        public double TransmissionCapacity { get; set; }
    }
}
