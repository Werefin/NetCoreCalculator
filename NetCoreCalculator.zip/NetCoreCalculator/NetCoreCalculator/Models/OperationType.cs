﻿namespace NetCoreCalculator.Models
{
    public enum OperationType
    {
        Addition,
        Multiplication,
        Division,
        Subtraction
    }
}