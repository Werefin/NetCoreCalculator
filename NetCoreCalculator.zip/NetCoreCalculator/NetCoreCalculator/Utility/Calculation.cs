﻿using NetCoreCalculator.Models;
using System;

namespace NetCoreCalculator.Utility
{
    // Calculates mathematics formulas
    public static class Calculation
    {
        // Compound Interest based on a given model
        // Formula: A = P [(1 + r)^{n}]

        public static double CalculateCompoundInterest(CompoundInterestModel model)
        {
            // P
            var initialInvestment = model.TimePeriod;

            // 1 + r
            var interestRateCalculation = 1 + GetPercentValue(model.InterestRate);

            // [(1 + r)^{n}]
            var powerResult = Math.Pow(interestRateCalculation, model.TimePeriod);

            // A = P [(1 + r)^{n}]
            return powerResult * model.Investment;
        }

        // Network Troughput based on a given model
        // Formula: THR = PE * TC

        public static double CalculateNetworkTroughput(NetworkTroughputModel model)
        {
            return model.ProtocolEfficiency * model.TransmissionCapacity;
        }

        // Converts the given percentage in a double number
        // Result = number / 100

        private static double GetPercentValue(double number)
        {
            return number / 100;
        }
    }
}