using NetCoreCalculator.Controllers;
using NetCoreCalculator.Models;
using NetCoreCalculator.Utility;
using Xunit;

namespace NetCoreCalculatorTest
{
    public class HomeControllerTest
    {
        private HomeController _controller;

        public HomeControllerTest()
        {
            _controller = new HomeController();
        }

        #region OperationsTest

        [Fact]
        public void OperationsTest()
        {
            Operation addition = new Operation
            {
                // Arrange
                NumberA = 1,
                NumberB = 2,
                OperationType = OperationType.Addition
            };

            Operation subtraction = new Operation
            {
                // Arrange
                NumberA = 1,
                NumberB = 2,
                OperationType = OperationType.Subtraction
            };

            Operation multiplication = new Operation
            {
                // Arrange
                NumberA = 1,
                NumberB = 2,
                OperationType = OperationType.Multiplication
            };

            Operation division = new Operation
            {
                // Arrange
                NumberA = 1,
                NumberB = 2,
                OperationType = OperationType.Division
            };

            // Act
            var testAddition = addition.NumberA + addition.NumberB;
            var testSubtraction = subtraction.NumberA - subtraction.NumberB;
            var testMultiplication = multiplication.NumberA * multiplication.NumberB;
            var testDivision = division.NumberA / division.NumberB;

            // Assert
            Assert.Equal(3, testAddition);
            Assert.Equal(-1, testSubtraction);
            Assert.Equal(2, testMultiplication);
            Assert.Equal(0.5, testDivision);
        }

        #endregion

        #region CompoundInterestTest

        [Fact]
        public void CompoundInterestTest()
        {
            CompoundInterestModel model = new CompoundInterestModel
            {
                // Arrange
                Investment = 100,
                InterestRate = 10,
                TimePeriod = 2
            };

            // Act
            var resultCI = Calculation.CalculateCompoundInterest(model);
            model.Result = Calculation.CalculateCompoundInterest(model);

            // Assert
            Assert.Equal(resultCI, model.Result);
        }

        #endregion

        #region NetworkTroughputTest

        [Fact]
        public void NetworkTroughputTest()
        {
            NetworkTroughputModel model = new NetworkTroughputModel
            {
                // Arrange
                ProtocolEfficiency = 0.75,
                TransmissionCapacity = 2.15
            };

            // Act
            var resultTHR = Calculation.CalculateNetworkTroughput(model);
            model.Result = Calculation.CalculateNetworkTroughput(model);

            // Assert
            Assert.Equal(resultTHR, model.Result);
        }

        #endregion
    }
}
